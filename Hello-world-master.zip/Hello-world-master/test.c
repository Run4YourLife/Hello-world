#include "stdio.h"

int main(void)
{
  printf("hello world");
  printf("\ndownloaded\n");
  getch();
  return 0;
}
